"""
Users application for QDI Portal
Handles user management and profiles
"""
default_app_config = 'apps.users.apps.UsersConfig'
