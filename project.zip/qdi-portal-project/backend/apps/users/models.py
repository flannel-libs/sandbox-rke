"""
User models for QDI Portal
"""
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.utils.translation import gettext_lazy as _
from apps.core.models import TimeStampedModel


class UserManager(BaseUserManager):
    """
    Custom user manager for User model
    """
    def create_user(self, email, password=None, **extra_fields):
        """Create and return a regular user"""
        if not email:
            raise ValueError(_('Email address is required'))
        
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, email, password=None, **extra_fields):
        """Create and return a superuser"""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        
        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True'))
        
        return self.create_user(email, password, **extra_fields)


class User(AbstractUser, TimeStampedModel):
    """
    Custom User model with email as the unique identifier
    """
    AUTH_PROVIDERS = (
        ('local', 'Local'),
        ('oidc', 'OIDC'),
        ('saml', 'SAML'),
        ('google', 'Google'),
        ('azure', 'Azure AD'),
    )
    
    username = None  # Remove username field
    email = models.EmailField(
        _('Email Address'),
        unique=True,
        help_text=_('Required. Enter a valid email address.')
    )
    first_name = models.CharField(
        _('First Name'),
        max_length=150,
        blank=True
    )
    last_name = models.CharField(
        _('Last Name'),
        max_length=150,
        blank=True
    )
    phone_number = models.CharField(
        _('Phone Number'),
        max_length=20,
        blank=True,
        null=True
    )
    avatar = models.ImageField(
        _('Avatar'),
        upload_to='avatars/',
        blank=True,
        null=True
    )
    bio = models.TextField(
        _('Bio'),
        blank=True,
        max_length=500
    )
    auth_provider = models.CharField(
        _('Auth Provider'),
        max_length=20,
        choices=AUTH_PROVIDERS,
        default='local'
    )
    external_id = models.CharField(
        _('External ID'),
        max_length=255,
        blank=True,
        null=True,
        unique=True,
        help_text=_('ID from external authentication provider')
    )
    last_provider_sync = models.DateTimeField(
        _('Last Provider Sync'),
        null=True,
        blank=True
    )
    is_email_verified = models.BooleanField(
        _('Email Verified'),
        default=False
    )
    
    objects = UserManager()
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']
    
    class Meta:
        db_table = 'users'
        verbose_name = _('User')
        verbose_name_plural = _('Users')
        indexes = [
            models.Index(fields=['email']),
            models.Index(fields=['auth_provider', 'external_id']),
        ]
    
    def __str__(self):
        return self.email
    
    def get_full_name(self):
        """Return the user's full name"""
        return f"{self.first_name} {self.last_name}".strip() or self.email
    
    def get_short_name(self):
        """Return the user's short name"""
        return self.first_name or self.email


class UserProfile(TimeStampedModel):
    """
    Extended user profile information
    """
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profile'
    )
    department = models.CharField(
        _('Department'),
        max_length=100,
        blank=True
    )
    job_title = models.CharField(
        _('Job Title'),
        max_length=100,
        blank=True
    )
    location = models.CharField(
        _('Location'),
        max_length=100,
        blank=True
    )
    timezone = models.CharField(
        _('Timezone'),
        max_length=50,
        default='UTC'
    )
    preferences = models.JSONField(
        _('Preferences'),
        default=dict,
        blank=True,
        help_text=_('User preferences and settings')
    )
    
    class Meta:
        db_table = 'user_profiles'
        verbose_name = _('User Profile')
        verbose_name_plural = _('User Profiles')
    
    def __str__(self):
        return f"Profile for {self.user.email}"
