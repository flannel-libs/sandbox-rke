"""
API views for QDI Portal
"""
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny


class RootAPIView(APIView):
    """
    Root API endpoint providing information about available endpoints
    """
    permission_classes = [AllowAny]
    
    def get(self, request):
        """
        Return API information
        """
        return Response({
            'message': 'Welcome to QDI Portal API',
            'version': '1.0.0',
            'endpoints': {
                'authentication': '/api/auth/',
                'users': '/api/users/',
                'health': '/api/health/',
                'documentation': {
                    'swagger': '/api/docs/',
                    'redoc': '/api/redoc/',
                }
            }
        })
