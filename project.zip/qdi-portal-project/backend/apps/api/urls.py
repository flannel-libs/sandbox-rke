"""
API URL Configuration
"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import RootAPIView

app_name = 'api'

router = DefaultRouter()
# Register viewsets here
# router.register(r'users', UserViewSet, basename='user')

urlpatterns = [
    path('', RootAPIView.as_view(), name='root'),
    path('', include(router.urls)),
]
