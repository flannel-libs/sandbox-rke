"""
Core application for QDI Portal
Contains base models, utilities, and common functionality
"""
default_app_config = 'apps.core.apps.CoreConfig'
