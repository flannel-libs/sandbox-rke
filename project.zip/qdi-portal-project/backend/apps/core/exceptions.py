"""
Custom exceptions and exception handler for QDI Portal
"""
from rest_framework.views import exception_handler
from rest_framework import status
from rest_framework.response import Response
from django.core.exceptions import ValidationError as DjangoValidationError


class QDIPortalException(Exception):
    """Base exception for QDI Portal"""
    default_message = 'An error occurred'
    default_code = 'error'
    
    def __init__(self, message=None, code=None):
        self.message = message or self.default_message
        self.code = code or self.default_code
        super().__init__(self.message)


class TrinoQueryError(QDIPortalException):
    """Exception raised for Trino query errors"""
    default_message = 'Trino query execution failed'
    default_code = 'trino_query_error'


class OpenSearchError(QDIPortalException):
    """Exception raised for OpenSearch errors"""
    default_message = 'OpenSearch operation failed'
    default_code = 'opensearch_error'


class InvalidCredentialsError(QDIPortalException):
    """Exception raised for invalid authentication credentials"""
    default_message = 'Invalid credentials provided'
    default_code = 'invalid_credentials'


def custom_exception_handler(exc, context):
    """
    Custom exception handler for DRF
    """
    # Call REST framework's default exception handler first
    response = exception_handler(exc, context)
    
    # Handle Django validation errors
    if isinstance(exc, DjangoValidationError):
        return Response({
            'success': False,
            'message': 'Validation error',
            'errors': exc.messages
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Handle custom exceptions
    if isinstance(exc, QDIPortalException):
        return Response({
            'success': False,
            'message': exc.message,
            'code': exc.code
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # If response is None, exception wasn't handled by DRF
    if response is None:
        return Response({
            'success': False,
            'message': 'Internal server error',
            'detail': str(exc)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    # Format DRF exceptions
    response.data = {
        'success': False,
        'message': response.data.get('detail', 'An error occurred'),
        'errors': response.data if not isinstance(response.data, str) else None
    }
    
    return response
