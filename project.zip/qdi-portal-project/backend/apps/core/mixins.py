"""
Reusable mixins for models and views
"""
from rest_framework import status
from rest_framework.response import Response


class SerializerByActionMixin:
    """
    Mixin to use different serializers for different actions
    """
    serializer_classes = {}
    
    def get_serializer_class(self):
        """
        Return the serializer class based on the action
        """
        return self.serializer_classes.get(
            self.action,
            self.serializer_class
        )


class MultipleFieldLookupMixin:
    """
    Apply this mixin to any view or viewset to get multiple field filtering
    based on a `lookup_fields` attribute, instead of the default single field filtering.
    """
    def get_object(self):
        queryset = self.get_queryset()
        queryset = self.filter_queryset(queryset)
        filter_kwargs = {}
        
        for field in self.lookup_fields:
            if self.kwargs.get(field):
                filter_kwargs[field] = self.kwargs[field]
        
        obj = queryset.get(**filter_kwargs)
        self.check_object_permissions(self.request, obj)
        return obj


class CustomResponseMixin:
    """
    Mixin to provide custom response format
    """
    def success_response(self, data=None, message='Success', status_code=status.HTTP_200_OK):
        """Return success response"""
        return Response({
            'success': True,
            'message': message,
            'data': data
        }, status=status_code)
    
    def error_response(self, message='Error', errors=None, status_code=status.HTTP_400_BAD_REQUEST):
        """Return error response"""
        response_data = {
            'success': False,
            'message': message,
        }
        if errors:
            response_data['errors'] = errors
        return Response(response_data, status=status_code)
