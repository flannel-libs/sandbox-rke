"""
Utility functions for QDI Portal
"""
import hashlib
import random
import string
from django.utils import timezone
from datetime import datetime, timedelta


def generate_random_string(length=32, use_digits=True, use_punctuation=False):
    """
    Generate a random string of specified length
    """
    chars = string.ascii_letters
    if use_digits:
        chars += string.digits
    if use_punctuation:
        chars += string.punctuation
    
    return ''.join(random.choice(chars) for _ in range(length))


def generate_hash(value, algorithm='sha256'):
    """
    Generate hash for a given value
    """
    hash_func = getattr(hashlib, algorithm)
    return hash_func(value.encode()).hexdigest()


def parse_date(date_string, format='%Y-%m-%d'):
    """
    Parse date string to datetime object
    """
    try:
        return datetime.strptime(date_string, format)
    except ValueError:
        return None


def get_client_ip(request):
    """
    Get client IP address from request
    """
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


def chunks(lst, n):
    """
    Yield successive n-sized chunks from list
    """
    for i in range(0, len(lst), n):
        yield lst[i:i + n]


def calculate_age(birth_date):
    """
    Calculate age from birth date
    """
    today = timezone.now().date()
    return today.year - birth_date.year - (
        (today.month, today.day) < (birth_date.month, birth_date.day)
    )


def time_ago(dt):
    """
    Get human-readable time difference
    """
    now = timezone.now()
    diff = now - dt
    
    if diff.days > 365:
        return f"{diff.days // 365} year(s) ago"
    elif diff.days > 30:
        return f"{diff.days // 30} month(s) ago"
    elif diff.days > 0:
        return f"{diff.days} day(s) ago"
    elif diff.seconds > 3600:
        return f"{diff.seconds // 3600} hour(s) ago"
    elif diff.seconds > 60:
        return f"{diff.seconds // 60} minute(s) ago"
    else:
        return "just now"
