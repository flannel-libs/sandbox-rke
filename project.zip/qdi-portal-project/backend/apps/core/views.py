"""
Core views for QDI Portal
"""
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from django.db import connection
from django.core.cache import cache
import logging

logger = logging.getLogger(__name__)


class HealthCheckView(APIView):
    """
    Health check endpoint for monitoring
    """
    permission_classes = [AllowAny]
    
    def get(self, request):
        """
        Check the health of various services
        """
        health = {
            'status': 'healthy',
            'service': 'qdi-portal-backend',
            'version': '1.0.0',
            'checks': {}
        }
        
        # Database check
        try:
            with connection.cursor() as cursor:
                cursor.execute('SELECT 1')
            health['checks']['database'] = 'ok'
        except Exception as e:
            logger.error(f"Database health check failed: {str(e)}")
            health['status'] = 'unhealthy'
            health['checks']['database'] = f'error: {str(e)}'
        
        # Cache check
        try:
            cache_key = 'health_check'
            cache.set(cache_key, 'ok', 10)
            result = cache.get(cache_key)
            if result == 'ok':
                health['checks']['cache'] = 'ok'
            else:
                raise Exception('Cache verification failed')
        except Exception as e:
            logger.error(f"Cache health check failed: {str(e)}")
            health['status'] = 'unhealthy'
            health['checks']['cache'] = f'error: {str(e)}'
        
        status_code = status.HTTP_200_OK if health['status'] == 'healthy' else status.HTTP_503_SERVICE_UNAVAILABLE
        return Response(health, status=status_code)


class RootView(APIView):
    """
    API root endpoint
    """
    permission_classes = [AllowAny]
    
    def get(self, request):
        """
        Display API information
        """
        return Response({
            'service': 'QDI Portal API',
            'version': '1.0.0',
            'endpoints': {
                'health': '/api/health/',
                'auth': '/api/auth/',
                'api': '/api/',
                'admin': '/admin/',
            }
        })
