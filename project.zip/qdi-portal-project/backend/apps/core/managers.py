"""
Custom model managers for QDI Portal
"""
from django.db import models


class SoftDeleteManager(models.Manager):
    """
    Manager that excludes soft-deleted objects by default
    """
    def get_queryset(self):
        """Return only non-deleted objects"""
        return super().get_queryset().filter(is_deleted=False)
    
    def with_deleted(self):
        """Return all objects including deleted ones"""
        return super().get_queryset()
    
    def only_deleted(self):
        """Return only deleted objects"""
        return super().get_queryset().filter(is_deleted=True)


class ActiveManager(models.Manager):
    """
    Manager that returns only active objects
    """
    def get_queryset(self):
        """Return only active objects"""
        return super().get_queryset().filter(is_active=True)
