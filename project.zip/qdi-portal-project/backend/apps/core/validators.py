"""
Custom validators for QDI Portal
"""
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
import re


def validate_phone_number(value):
    """
    Validate phone number format
    """
    phone_regex = re.compile(r'^\+?1?\d{9,15}$')
    if not phone_regex.match(value):
        raise ValidationError(
            _('Phone number must be entered in the format: "+999999999". Up to 15 digits allowed.')
        )


def validate_alphanumeric(value):
    """
    Validate that the value contains only alphanumeric characters
    """
    if not value.isalnum():
        raise ValidationError(
            _('This field must contain only letters and numbers.')
        )


def validate_file_size(value, max_size_mb=5):
    """
    Validate file size
    """
    filesize = value.size
    max_size_bytes = max_size_mb * 1024 * 1024
    
    if filesize > max_size_bytes:
        raise ValidationError(
            _('File size must not exceed %(max_size)s MB') % {'max_size': max_size_mb}
        )


def validate_file_extension(value, allowed_extensions=None):
    """
    Validate file extension
    """
    if allowed_extensions is None:
        allowed_extensions = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png']
    
    import os
    ext = os.path.splitext(value.name)[1][1:].lower()
    
    if ext not in allowed_extensions:
        raise ValidationError(
            _('Unsupported file extension. Allowed extensions: %(extensions)s') % {
                'extensions': ', '.join(allowed_extensions)
            }
        )
