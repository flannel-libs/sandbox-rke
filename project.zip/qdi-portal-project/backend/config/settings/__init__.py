"""
Settings package for QDI Portal
"""
