"""
QDI Portal URL Configuration
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # API endpoints
    path('api/', include('apps.api.urls', namespace='api')),
    
    # Authentication
    path('api/auth/', include('apps.authentication.urls', namespace='authentication')),
    
    # Health check
    path('api/health/', include('apps.core.urls')),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

# Configure admin site headers
admin.site.site_header = 'QDI Portal Administration'
admin.site.site_title = 'QDI Portal Admin'
admin.site.index_title = 'Welcome to QDI Portal Administration'
