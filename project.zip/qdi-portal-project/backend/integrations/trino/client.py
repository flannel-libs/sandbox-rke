"""
Trino database client for QDI Portal
Provides connection and query execution for Trino distributed SQL engine
"""
import trino
from django.conf import settings
from apps.core.exceptions import TrinoQueryError
import logging

logger = logging.getLogger(__name__)


class TrinoClient:
    """
    Client for connecting to and querying Trino
    """
    
    def __init__(self):
        """Initialize Trino connection"""
        self.host = settings.TRINO_HOST
        self.port = settings.TRINO_PORT
        self.user = settings.TRINO_USER
        self.catalog = settings.TRINO_CATALOG
        self.schema = settings.TRINO_SCHEMA
        self.http_scheme = settings.TRINO_HTTP_SCHEME
        self._connection = None
    
    def _get_connection(self):
        """
        Get or create Trino connection
        """
        if self._connection is None:
            try:
                self._connection = trino.dbapi.connect(
                    host=self.host,
                    port=self.port,
                    user=self.user,
                    catalog=self.catalog,
                    schema=self.schema,
                    http_scheme=self.http_scheme,
                )
                logger.info(f"Connected to Trino at {self.host}:{self.port}")
            except Exception as e:
                logger.error(f"Failed to connect to Trino: {str(e)}")
                raise TrinoQueryError(f"Failed to connect to Trino: {str(e)}")
        return self._connection
    
    def execute_query(self, query, params=None):
        """
        Execute a query and return results
        
        Args:
            query (str): SQL query to execute
            params (tuple): Query parameters for parameterized queries
            
        Returns:
            list: Query results as list of tuples
        """
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            
            results = cursor.fetchall()
            logger.info(f"Query executed successfully. Returned {len(results)} rows.")
            return results
            
        except Exception as e:
            logger.error(f"Trino query execution failed: {str(e)}")
            raise TrinoQueryError(f"Query execution failed: {str(e)}")
    
    def execute_query_as_dict(self, query, params=None):
        """
        Execute a query and return results as list of dictionaries
        
        Args:
            query (str): SQL query to execute
            params (tuple): Query parameters
            
        Returns:
            list: Query results as list of dictionaries
        """
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            
            columns = [desc[0] for desc in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            logger.info(f"Query executed successfully. Returned {len(results)} rows.")
            return results
            
        except Exception as e:
            logger.error(f"Trino query execution failed: {str(e)}")
            raise TrinoQueryError(f"Query execution failed: {str(e)}")
    
    def get_tables(self, schema=None):
        """
        Get list of tables in a schema
        
        Args:
            schema (str): Schema name (uses default if not provided)
            
        Returns:
            list: List of table names
        """
        schema = schema or self.schema
        query = f"SHOW TABLES FROM {self.catalog}.{schema}"
        
        try:
            results = self.execute_query(query)
            return [row[0] for row in results]
        except Exception as e:
            logger.error(f"Failed to get tables: {str(e)}")
            raise TrinoQueryError(f"Failed to get tables: {str(e)}")
    
    def get_table_schema(self, table_name, schema=None):
        """
        Get schema information for a table
        
        Args:
            table_name (str): Name of the table
            schema (str): Schema name (uses default if not provided)
            
        Returns:
            list: List of dictionaries with column information
        """
        schema = schema or self.schema
        query = f"DESCRIBE {self.catalog}.{schema}.{table_name}"
        
        try:
            return self.execute_query_as_dict(query)
        except Exception as e:
            logger.error(f"Failed to get table schema: {str(e)}")
            raise TrinoQueryError(f"Failed to get table schema: {str(e)}")
    
    def close(self):
        """Close Trino connection"""
        if self._connection:
            try:
                self._connection.close()
                logger.info("Trino connection closed")
            except Exception as e:
                logger.error(f"Error closing Trino connection: {str(e)}")
            finally:
                self._connection = None
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()


# Singleton instance
_trino_client = None


def get_trino_client():
    """
    Get or create singleton Trino client instance
    """
    global _trino_client
    if _trino_client is None:
        _trino_client = TrinoClient()
    return _trino_client
