# QDI Portal

Enterprise Data Analytics Platform built with Django and Next.js

## 🏗️ Architecture

- **Backend**: Django 5.2 + Django REST Framework
- **Frontend**: Next.js 15 + React 19 + TailwindCSS 3.4
- **Database**: PostgreSQL 16
- **Cache**: Redis 7
- **Search**: OpenSearch 2.18
- **Analytics**: Trino 467
- **Task Queue**: Celery 5.4
- **Deployment**: Docker Swarm

## 📋 Prerequisites

- Python 3.10+
- Node.js 20+
- Docker & Docker Compose
- PostgreSQL 16
- Redis 7

## 🚀 Quick Start

### Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements/development.txt

# Create .env file
cp .env.example .env
# Edit .env with your configuration

# Run migrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Run development server
python manage.py runserver
```

### Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Create .env.local file
cp .env.local.example .env.local
# Edit .env.local with your configuration

# Run development server
npm run dev
```

Visit:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000/api
- Admin: http://localhost:8000/admin

## 📁 Project Structure

```
qdi-portal-project/
├── backend/                    # Django backend
│   ├── config/                # Project configuration
│   │   ├── settings/         # Split settings
│   │   ├── urls.py           # Root URLs
│   │   ├── wsgi.py           # WSGI config
│   │   └── asgi.py           # ASGI config
│   ├── apps/                  # Django applications
│   │   ├── core/             # Core utilities
│   │   ├── users/            # User management
│   │   ├── authentication/   # Auth & JWT
│   │   ├── api/              # API views
│   │   └── search/           # OpenSearch integration
│   ├── integrations/          # External services
│   │   ├── trino/            # Trino client
│   │   └── opensearch/       # OpenSearch client
│   ├── requirements/          # Python dependencies
│   └── manage.py             # Django management
│
└── frontend/                  # Next.js frontend
    ├── src/
    │   ├── app/              # Next.js App Router
    │   ├── components/       # React components
    │   ├── lib/              # Utilities & API client
    │   └── types/            # TypeScript types
    ├── public/               # Static assets
    └── package.json          # Node dependencies
```

## 🔧 Configuration

### Environment Variables

#### Backend (.env)
```
DEBUG=True
SECRET_KEY=your-secret-key
DATABASE_URL=postgresql://user:pass@localhost:5432/portal_db
REDIS_URL=redis://localhost:6379/0
CORS_ALLOWED_ORIGINS=http://localhost:3000
```

#### Frontend (.env.local)
```
NEXT_PUBLIC_API_URL=http://localhost:8000/api
```

## 🧪 Testing

### Backend
```bash
cd backend
pytest
```

### Frontend
```bash
cd frontend
npm test
```

## 📦 Deployment

### Docker Swarm
```bash
# Build image
docker build -t qdi-portal:latest -f Dockerfile .

# Deploy stack
docker stack deploy -c docker-stack.yml portal
```

## 🔐 Authentication

The project supports multiple authentication methods:
- Local (Email/Password)
- OpenID Connect (OIDC)
- SAML 2.0
- OAuth 2.0 with JWT tokens

## 📖 API Documentation

API documentation is available at:
- Swagger UI: http://localhost:8000/api/docs/
- ReDoc: http://localhost:8000/api/redoc/

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License.

## 👥 Team

QDI Development Team

## 📞 Support

For support, email support@qdi-portal.com
