# QDI Portal - Quick Start (5 Minutes)

## 🚀 Get Running in 5 Minutes

### Prerequisites Check
```bash
python --version    # Should be 3.10+
node --version      # Should be 20+
psql --version      # Should be 16+
redis-cli --version # Should be 7+
```

### Step 1: Setup Backend (2 minutes)

```bash
# Navigate to backend
cd backend

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements/development.txt

# Copy environment file
cp .env.example .env

# Edit .env (set these minimum values)
# DEBUG=True
# SECRET_KEY=your-random-secret-key
# DATABASE_URL=postgresql://portal_user:password@localhost:5432/portal_db

# Create database
createdb portal_db

# Run migrations
python manage.py migrate

# Create superuser (follow prompts)
python manage.py createsuperuser

# Start server
python manage.py runserver
```

✅ Backend running at: http://localhost:8000

### Step 2: Setup Frontend (2 minutes)

```bash
# Open new terminal
cd frontend

# Install dependencies
npm install

# Copy environment file
cp .env.local.example .env.local

# Start dev server
npm run dev
```

✅ Frontend running at: http://localhost:3000

### Step 3: Test It (1 minute)

1. **Visit Frontend**: http://localhost:3000
   - Should see QDI Portal homepage
   - Should see backend health status as "healthy"

2. **Visit Admin**: http://localhost:8000/admin
   - Login with superuser credentials
   - Browse the admin interface

3. **Test API**: http://localhost:8000/api/
   - Should see API root with endpoints

## 🎉 That's It!

You now have:
- ✅ Django backend running
- ✅ Next.js frontend running
- ✅ Database configured
- ✅ Authentication working
- ✅ API accessible

## 📖 Next Steps

1. **Read the SETUP_GUIDE.md** for detailed information
2. **Check PROJECT_SUMMARY.md** to see what's included
3. **Start building features** - everything is ready!

## 🐛 Quick Fixes

### Backend won't start
```bash
# Check if database exists
psql -l | grep portal_db

# If not, create it
createdb portal_db
python manage.py migrate
```

### Frontend won't start
```bash
# Clear and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Can't connect to backend
- Check backend is running on port 8000
- Check NEXT_PUBLIC_API_URL in frontend/.env.local
- Check CORS_ALLOWED_ORIGINS in backend/.env

## 💡 Pro Tips

1. Keep both terminals open (backend + frontend)
2. Use different ports if 3000 or 8000 are taken
3. Check logs in terminals for errors
4. Use `python manage.py shell` for quick DB tests
5. Use browser DevTools Network tab to debug API calls

---

**Need help?** Check the full SETUP_GUIDE.md or contact the team.
