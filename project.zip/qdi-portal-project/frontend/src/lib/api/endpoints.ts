/**
 * API Endpoints for QDI Portal
 */
import apiClient from './client'

export const authAPI = {
  login: (email: string, password: string) => 
    apiClient.post('/auth/login/', { email, password }),
  
  register: (userData: any) => 
    apiClient.post('/auth/register/', userData),
  
  logout: () => 
    apiClient.post('/auth/logout/'),
  
  refreshToken: (refresh: string) => 
    apiClient.post('/auth/token/refresh/', { refresh }),
  
  getCurrentUser: () => 
    apiClient.get('/auth/me/'),
}

export const usersAPI = {
  list: (params?: any) => 
    apiClient.get('/users/', params),
  
  get: (id: number) => 
    apiClient.get(`/users/${id}/`),
  
  update: (id: number, data: any) => 
    apiClient.patch(`/users/${id}/`, data),
  
  delete: (id: number) => 
    apiClient.delete(`/users/${id}/`),
}

export const healthAPI = {
  check: () => 
    apiClient.get('/health/'),
}

// Export all APIs
export default {
  auth: authAPI,
  users: usersAPI,
  health: healthAPI,
}
