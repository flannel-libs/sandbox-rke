/**
 * TypeScript types for QDI Portal
 */

export interface User {
  id: number
  email: string
  first_name: string
  last_name: string
  full_name: string
  phone_number?: string
  avatar?: string
  bio?: string
  auth_provider: 'local' | 'oidc' | 'saml' | 'google' | 'azure'
  is_active: boolean
  is_email_verified: boolean
  created_at: string
  profile?: UserProfile
}

export interface UserProfile {
  department?: string
  job_title?: string
  location?: string
  timezone: string
  preferences: Record<string, any>
}

export interface AuthTokens {
  access: string
  refresh: string
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  email: string
  first_name: string
  last_name: string
  password: string
  password_confirm: string
  phone_number?: string
}

export interface HealthCheck {
  status: 'healthy' | 'unhealthy' | 'degraded'
  service: string
  version: string
  checks: {
    database?: string
    cache?: string
    [key: string]: string | undefined
  }
}

export interface APIResponse<T = any> {
  success: boolean
  message: string
  data?: T
  errors?: any
}

export interface PaginatedResponse<T> {
  count: number
  next: string | null
  previous: string | null
  results: T[]
}
