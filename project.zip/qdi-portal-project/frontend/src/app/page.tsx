'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function Home() {
  const [health, setHealth] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check backend health
    fetch(`${process.env.NEXT_PUBLIC_API_URL}/health/`)
      .then(res => res.json())
      .then(data => {
        setHealth(data)
        setLoading(false)
      })
      .catch(err => {
        console.error('Failed to fetch health:', err)
        setLoading(false)
      })
  }, [])

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <div className="z-10 max-w-5xl w-full items-center justify-center font-mono text-sm">
        <h1 className="text-6xl font-bold text-center mb-8 bg-gradient-to-r from-primary-500 to-secondary-500 bg-clip-text text-transparent">
          QDI Portal
        </h1>
        
        <p className="text-xl text-center mb-12 text-gray-600 dark:text-gray-400">
          Enterprise Data Analytics Platform
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="p-6 border border-gray-200 dark:border-gray-800 rounded-lg hover:shadow-lg transition-shadow">
            <h2 className="text-2xl font-semibold mb-4">🚀 Features</h2>
            <ul className="space-y-2 text-gray-600 dark:text-gray-400">
              <li>✓ Django 5.2 REST API Backend</li>
              <li>✓ Next.js 15 React Frontend</li>
              <li>✓ PostgreSQL Database</li>
              <li>✓ Redis Caching</li>
              <li>✓ OpenSearch Integration</li>
              <li>✓ Trino Analytics Engine</li>
              <li>✓ JWT Authentication</li>
              <li>✓ Celery Task Queue</li>
            </ul>
          </div>

          <div className="p-6 border border-gray-200 dark:border-gray-800 rounded-lg hover:shadow-lg transition-shadow">
            <h2 className="text-2xl font-semibold mb-4">🔌 Backend Status</h2>
            {loading ? (
              <p className="text-gray-600">Loading...</p>
            ) : health ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span>Status:</span>
                  <span className={`font-semibold ${
                    health.status === 'healthy' ? 'text-green-500' : 'text-red-500'
                  }`}>
                    {health.status || 'Unknown'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Service:</span>
                  <span className="font-semibold">{health.service || 'N/A'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Version:</span>
                  <span className="font-semibold">{health.version || 'N/A'}</span>
                </div>
                {health.checks && (
                  <div className="mt-4">
                    <p className="font-semibold mb-2">Health Checks:</p>
                    <div className="space-y-1 text-sm">
                      {Object.entries(health.checks).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <span className="capitalize">{key}:</span>
                          <span className={`${
                            value === 'ok' ? 'text-green-500' : 'text-red-500'
                          }`}>
                            {value as string}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-red-500">Backend connection failed</p>
            )}
          </div>
        </div>

        <div className="flex gap-4 justify-center">
          <Link 
            href="/login" 
            className="px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors font-semibold"
          >
            Login
          </Link>
          <Link 
            href="/dashboard" 
            className="px-6 py-3 border border-primary-600 text-primary-600 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-950 transition-colors font-semibold"
          >
            Dashboard
          </Link>
        </div>

        <div className="mt-16 text-center text-sm text-gray-500">
          <p>Built with Django, Next.js, and TailwindCSS</p>
          <p className="mt-2">© 2025 QDI Portal. All rights reserved.</p>
        </div>
      </div>
    </main>
  )
}
